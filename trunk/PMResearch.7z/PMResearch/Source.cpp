/*
   ---------------------------------------------------------------------------
   |               I M P L I C I T   S U R F A C E S   D E M O               |
   ---------------------------------------------------------------------------
                              
   Copyright (c) 2009 - 2010 Denis Bogolepov ( denisbogol @ gmail.com )

   This program is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the Free
   Software Foundation, either version 3 of the License, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
   or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
   for more details.

   You should have received a copy of the GNU General Public License along
   with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#define PHOTON_MAPPING

#define NAIVE_VERSION_
#define HALF_NAIVE_VERSION_
#define VOXEL_VERSION

#define NOMINMAX

#include <iostream>
#include <fstream>

#include <logger.h>

#include <Graphics.hpp>

#include "MyOpenCL.h"

using namespace graphics;
using std::ofstream;

/***************************************************************************************/
/*                                  GLOBAL VARIABLES                                   */
/***************************************************************************************/

/*
 * Camera control with mouse ( orientation ) and keyboard ( position ).
 */

Mouse mouse;

Keyboard keyboard ( 3.0F );

Camera camera ( Vector3f ( 0.0F, 0.0F, -18.0F ) /* position */,
                Vector3f ( 0.0F, 0.0F,   0.0F ) /* orientation */ );

/*
 * Number of photons in the photon map.
 */

GLuint N = 256;

GLuint M = 256;

GLuint voxels_x = 512;
GLuint voxels_y = 512;

const int max_voxel = 200;

/*
 * Positions ( XYZ ) and radiuses ( W ) of metaballs.
 */

const GLint count = 4;

Vector4f positions [count] = {
    Vector4f ( 0.0F, 0.0F, 0.0F, 0.50F ),
    Vector4f ( 0.0F, 0.0F, 0.0F, 0.65F ),
    Vector4f ( 0.0F, 0.0F, 0.0F, 0.80F ),
    Vector4f ( 0.0F, 0.0F, 0.0F, 0.95F )
};

/*
 * Light position and photon emission settings.
 */

/*
              *<-------- point light source
             /|\
            / | \
           /  |<-\------ distance to the floor
          /   |   \
       |-/----|----\-|
       |/     x     \|
       |             | 
       |-------------|
       radius x radius
            floor 
*/

Vector3f lightPosition = Vector3f ( 0.0F, 0.0F, 0.0F );

Vector2f lightRadius = Vector2f ( 5.0F, 5.0F );

float lightDistance = 5.0F;

/*
 * OpenCL objects.
 */

cl_context context;

cl_program program;

cl_kernel readKernel;
cl_kernel writeKernel;
cl_kernel sortKernel;
cl_kernel photonKeysKernel;
cl_kernel voxelCleanKernel;
cl_kernel voxelSetupKernel;
cl_kernel voxelWriteKernel;

cl_mem photonImage;
cl_mem photonBuffer;
cl_mem photonIndex;

cl_mem voxelImage;
cl_mem voxelBuffer;

cl_command_queue queue;

/***************************************************************************************/
/*                                   EVENT HANDLERS                                    */
/***************************************************************************************/

void MouseMoveHandler ( int x, int y )
{
    mouse.MouseMoveHandler ( x, y );
}
        
void MouseDownHandler ( int button, int state )
{
    mouse.MouseDownHandler ( button, state );
}

void KeyDownHandler ( int key, int state )
{
    keyboard.KeyDownHandler ( key, state );
}

/***************************************************************************************/
/*                                 OPENCL SUBROUTINES                                  */
/***************************************************************************************/

void SetupOpenCL ( void )
{
    /*
     * Obtain the list of platforms available ( AMD / NVIDIA ).
     * In this tutorial we use only first platform available.
     */

    VECTOR < cl_platform_id > platforms = cltGetPlatforms ( );

    /*
     * Create an OpenCL context from a device type based on
     * current OpenGL context.
     *
     * NOTE: You can create OpenCL context from OpenGL only
     * for GPU device.
     */

    context = cltCreateContextFromOpenGL ( platforms [0] );

    /*
     * Obtain the list of devices available on a platform.
     * In this tutorial we use only first device available.
     */
    
    VECTOR < cl_device_id > devices = cltGetDevices ( context );

    /*
     * Load and build a program object for a context.
     */

	std::string prefix = "";

#ifdef HALF_NAIVE_VERSION
	prefix += "#define X_SORT	\n\
			  ";
#endif

    program = cltLoadProgram ( context, "Sort.cl" , prefix.c_str() );
    
    cltBuildProgram ( program, devices );

    /*
     * Create a command-queue on a specific device.
     */
    
    queue = cltCreateQueue ( context, devices [0] );
}

void SetupKernels ( Texture2D & photons , Texture2D & voxels )
{
    /*
     * Create a kernel objects for a functions declared in a program.
     */

    readKernel = cltCreateKernel ( program, "Read" );

    writeKernel = cltCreateKernel ( program, "Write" );

    sortKernel = cltCreateKernel ( program, "Sort" );

	photonKeysKernel = cltCreateKernel( program , "PhotonIndex" );

	voxelCleanKernel = cltCreateKernel( program , "VoxelClean" );
	voxelSetupKernel = cltCreateKernel( program , "VoxelSetup" );
	voxelWriteKernel = cltCreateKernel( program , "VoxelWrite" );

    /*
     * Create an OpenCL 2D image object from an OpenGL 2D texture
     * object for output rendered scene.
     */

    photonImage = cltCreateImageFromTexture (
        context,
        CL_MEM_READ_WRITE,
        &photons );

	voxelImage = cltCreateImageFromTexture(
		context,
		CL_MEM_WRITE_ONLY,
		&voxels );
    
    /*
     * Create an OpenCL buffer object for array of photons.
     */

    photonBuffer = cltCreateBuffer < cl_float4 > (
        context,
        CL_MEM_READ_WRITE,
        N * M );
	photonIndex = cltCreateBuffer < cl_float4 > (
        context,
        CL_MEM_READ_WRITE,
        N * M );
	voxelBuffer = cltCreateBuffer < cl_float4 > (
        context,
        CL_MEM_READ_WRITE,
        voxels_x * voxels_y );
}

cl_uint descending = 1;

void StartKernels ( Texture2D & photons )
{
    /********************************************************************/
    /* STEP 1 -- Read data from texture and write it to buffer          */
    /********************************************************************/

    cltSetArgument < cl_mem > ( readKernel, 0, &photonImage );

    cltSetArgument < cl_mem > ( readKernel, 1, &photonBuffer );

    cltSetArgument < cl_uint > ( readKernel, 2, &N );

    cltRunKernel2D ( queue, readKernel, N, M, 8, 8 );
    cltCheckError ( clFinish ( queue ) );

#ifdef VOXEL_VERSION

	cltSetArgument < cl_mem > ( photonKeysKernel, 0, &photonBuffer );
	cltSetArgument < cl_mem > ( photonKeysKernel, 1, &photonIndex );

	cltRunKernel2D( queue , photonKeysKernel , N , M , 8 , 8 );
	cltCheckError ( clFinish ( queue ) );

#endif

    /********************************************************************/
    /* STEP 2 -- Sort data in the buffer with bitonic sort              */
    /********************************************************************/

    /*
     * Length - number of elements in the array.
     */

    cl_uint length = N * M;

    /*
     * Calculate number of stages.
     */

    cl_uint stagesNumber = 0;

    for ( cl_uint temp = length; temp > 1; temp >>= 1 )
    {
        ++stagesNumber;
    }

    /*
     * Set appropriate arguments to the kernel.
     */

    /* The input array - also acts as output for this pass (input for next) */

    cltSetArgument < cl_mem > ( sortKernel, 0, &photonBuffer );
    cltSetArgument < cl_mem > ( sortKernel, 5, &photonIndex );

    cltSetArgument < cl_uint > ( sortKernel, 3, &length );

    /* whether sort is to be in increasing order. CL_TRUE implies increasing */

    cltSetArgument < cl_uint > ( sortKernel, 4, &descending );

    cl_event events [2];

    for ( cl_uint stage = 0; stage < stagesNumber; ++stage )
    {
        /* stage of the algorithm */

         cltSetArgument < cl_uint > ( sortKernel, 1,  &stage );

        /* Every stage has stage + 1 passes */

        for ( cl_uint pass = 0; pass < stage + 1; ++pass )
        {
            /* pass of the current stage */

            cltSetArgument < cl_uint > ( sortKernel, 2,  &pass );

            cltRunKernel1D (
                queue,
                sortKernel,
                length / 2,
                64,
                &events [0] );

            /* wait for the kernel call to finish execution */

            cltCheckError ( clWaitForEvents ( 1, &events [0] ) );
        }
    }

    /* Enqueue read buffer */

    //cl_float4 * bbb = ( cl_float4 * )
    //    _aligned_malloc ( length * sizeof ( cl_float4 ), 16 );

    //cltCheckError ( clEnqueueReadBuffer (
    //    queue,
    //    photonBuffer,
    //    CL_TRUE,
    //    0,
    //    length * sizeof ( cl_float4 ),
    //    bbb,
    //    0,
    //    NULL,
    //    NULL ) );

    //{
    //    float pointx = -1.0F;

    //    int left = 0;

    //    int right = N * M;

    //    int center;

    //    while ( left < right )
    //    {
    //        center = ( left + right ) / 2;

    //        float photonx = bbb [center].s [0];
    //            //*(photons.Data->Pixel ( center - N*(center / N), center / M ));

    //        left = pointx < photonx ? ++center : left;

    //        right = pointx > photonx ? --center : right;      
    //    }

    //    pointx = bbb [center].s [0];

    //    pointx++;
    //}



    //EZLOGGERSTREAM << "\n\nSORT BUFFER\n\n";

    //for ( int i = 0; i < length; i++ )
    //{
    //    EZLOGGERSTREAM << bbb [i].s [0] << "\t" <<
    //                      bbb [i].s [1] << "\t" <<
    //                      bbb [i].s [2] << "\n";
    //} exit(0);

    /********************************************************************/
    /* STEP 3 -- Write data back from the buffer to the image           */
    /********************************************************************/

#ifdef VOXEL_VERSION

    cltSetArgument < cl_mem > ( voxelCleanKernel, 0, &voxelBuffer );
	cltRunKernel2D ( queue, voxelCleanKernel, voxels_x , voxels_y , 8, 8 );
	cltCheckError ( clFinish ( queue ) );

	cltSetArgument < cl_mem > ( voxelSetupKernel, 0, &photonIndex );
	cltSetArgument < cl_mem > ( voxelSetupKernel, 1, &voxelBuffer );
	cltRunKernel2D ( queue, voxelSetupKernel, N , M , 8, 8 );
	cltCheckError ( clFinish ( queue ) );

	cltSetArgument < cl_mem > ( writeKernel, 1, &voxelBuffer );
	cltSetArgument < cl_mem > ( writeKernel, 0, &voxelImage );
	cltSetArgument < cl_uint > ( writeKernel, 2, &voxels_x );
	cltRunKernel2D ( queue, writeKernel, voxels_x , voxels_y , 8, 8 );
	cltCheckError ( clFinish ( queue ) );

#endif

    cltSetArgument < cl_mem > ( writeKernel, 0, &photonImage );
    cltSetArgument < cl_mem > ( writeKernel, 1, &photonBuffer );
    cltSetArgument < cl_uint > ( writeKernel, 2, &N );

    cltRunKernel2D ( queue, writeKernel, N, M, 8, 8 );

    cltCheckError ( clFinish ( queue ) );
}

cl_int ReleaseOpenCL ( void )
{
    cltCheckError ( clReleaseKernel ( readKernel ) );

    cltCheckError ( clReleaseKernel ( writeKernel ) );

	cltCheckError ( clReleaseKernel ( voxelCleanKernel ) );

	cltCheckError ( clReleaseKernel ( voxelSetupKernel ) );

	cltCheckError ( clReleaseKernel ( voxelWriteKernel ) );

    cltCheckError ( clReleaseKernel ( sortKernel ) );

    cltCheckError ( clReleaseProgram ( program ) );

    cltCheckError ( clReleaseMemObject ( photonImage ) );

    cltCheckError ( clReleaseMemObject ( photonBuffer ) );

	cltCheckError ( clReleaseMemObject ( photonIndex ) );

	cltCheckError ( clReleaseMemObject ( voxelImage ) );

    cltCheckError ( clReleaseMemObject ( voxelBuffer ) );

    cltCheckError ( clReleaseCommandQueue ( queue ) );

    cltCheckError ( clReleaseContext ( context ) );

    return CL_SUCCESS;
}

/***************************************************************************************/
/*                                     ENTRY POINT                                     */
/***************************************************************************************/

int main ( void )
{
    /* We use GLFW for window management and OpenGL output */

    glfwInit ( );

    //-------------------------------------------------------------------------

    /* Choose video mode ( window or fullscreen ) */

    std :: cout << "Do you want to run program in fullscreen mode? [Y/N]\n";

    int choice = getchar ( );

    int width = 512, height = 512, mode = GLFW_WINDOW;

    //-------------------------------------------------------------------------

    /* Set video mode ( window or fullscreen ) */

    if ( choice == 'Y' || choice == 'y' )
    {
        GLFWvidmode vidmode;

        glfwGetDesktopMode ( &vidmode );

        width = vidmode.Width;
        
        height = vidmode.Height;

        mode = GLFW_FULLSCREEN;
    }

    //-------------------------------------------------------------------------

    /* Try to open rendering window */

    if ( !glfwOpenWindow (
            width    /* window width */,
            height   /* window height */,
            0        /* bits for red channel ( default ) */,
            0        /* bits for green channel ( default ) */,
            0        /* bits for blue channel ( default ) */,
            0        /* bits for alpha channel ( default ) */,
            0        /* bits for depth buffer ( not used ) */,
            0        /* bits for stencil buffer ( not used ) */,
            mode     /* windows mode ( fullscreen or window ) */ ) )
    {
        glfwTerminate ( ); exit ( 0 );
    }

    //-------------------------------------------------------------------------

    /* Set event handlers for mouse and keyboard */

    glfwSwapInterval ( 0 );

    glfwSetMousePosCallback ( MouseMoveHandler );

    glfwSetMouseButtonCallback ( MouseDownHandler );

    glfwSetKeyCallback ( KeyDownHandler );

    //-------------------------------------------------------------------------

    /* Set parallel projection for drawing dummy quad */
    
    glMatrixMode ( GL_PROJECTION );
    
    glLoadIdentity ( );
    
    glOrtho ( -1.0F, 1.0F, -1.0F, 1.0F, -1.0F, 1.0F );
    
    glMatrixMode ( GL_MODELVIEW );
    
    glLoadIdentity ( );

    /* Set view frustum for camera ( we use default values ) */

    camera.SetViewFrustum ( );

    //-------------------------------------------------------------------------

    /* Setup OpenCL compute environment */

    SetupOpenCL ( );

    /*
     * NOTE: From ATI Stream SDK v2.1 Developer Release Notes
     *
     * For OpenGL interoperability with OpenCL, there currently is a
     * requirement on when the OpenCL context is created and when
     * texture / buffer shared allocations can be made. To use shared
     * resources, the OpenGL application must create an OpenGL context
     * and then an OpenCL context. All resources ( GL buffers and
     * textures ) created after creation of the OpenCL context can be
     * shared between OpenGL and OpenCL. If resources are allocated before
     * the OpenCL context creation, they cannot be shared between OpenGL
     * and OpenCL.
     */

    /* Create photon map texture with specified size */

    Texture2D photonMap (
        0,
        new TextureData2D ( N, M, 4 ),
        GL_TEXTURE_RECTANGLE_ARB );
    photonMap.Setup ( );

	Texture2D voxelData (
        7,
        new TextureData2D ( voxels_x, voxels_y, 4 ),
        GL_TEXTURE_RECTANGLE_ARB );
    voxelData.Setup ( );

    /* Create other textures and normal maps */

    Texture2D floorColor (
        1,
        TextureData2D :: LoadFromFile ( "Maps/FloorColor.JPG" ),
        GL_TEXTURE_2D );
    floorColor.FilterMode = FilterMode :: Linear;
    floorColor.WrapMode = WrapMode :: Repeat;
    floorColor.Setup ( );

    Texture2D floorNormal (
        2,
        TextureData2D :: LoadFromFile ( "Maps/FloorNormal.JPG" ),
        GL_TEXTURE_2D );
    floorNormal.FilterMode = FilterMode :: Linear;
    floorNormal.WrapMode = WrapMode :: Repeat;
    floorNormal.Setup ( );

    Texture2D wallColor (
        3,
        TextureData2D :: LoadFromFile ( "Maps/WallColor.JPG" ),
        GL_TEXTURE_2D );
    wallColor.FilterMode = FilterMode :: Linear;
    wallColor.WrapMode = WrapMode :: Repeat;
    wallColor.Setup ( );

    Texture2D wallNormal (
        4,
        TextureData2D :: LoadFromFile ( "Maps/WallNormal.JPG" ),
        GL_TEXTURE_2D );
    wallNormal.FilterMode = FilterMode :: Linear;
    wallNormal.WrapMode = WrapMode :: Repeat;
    wallNormal.Setup ( );

    Texture2D ceilColor (
        5,
        TextureData2D :: LoadFromFile ( "Maps/CeilColor.JPG" ),
        GL_TEXTURE_2D );
    ceilColor.FilterMode = FilterMode :: Linear;
    ceilColor.WrapMode = WrapMode :: Repeat;
    ceilColor.Setup ( );

    Texture2D ceilNormal (
        6,
        TextureData2D :: LoadFromFile ( "Maps/CeilNormal.JPG" ),
        GL_TEXTURE_2D );
    ceilNormal.FilterMode = FilterMode :: Linear;
    ceilNormal.WrapMode = WrapMode :: Repeat;
    ceilNormal.Setup ( );

    /* Now we can work with the photon texture */

    SetupKernels ( photonMap , voxelData );

    //-------------------------------------------------------------------------

    /* Load and compile shader files for LIGHT PASS */

    ShaderProgram lightProgram;
    
    if ( !lightProgram.LoadVertexShader ( "Vertex.glsl" ) )
    {
        std :: cout << "ERROR: failed to load vertex shader\n"; exit ( -1 );
    }
    
    if ( !lightProgram.LoadFragmentShader ( "Fragment.glsl",
                                            "#define LIGHT_PASS\n\
											" ) )
    {
        std :: cout << "ERROR: failed to load fragment shader\n"; exit ( -1 );
    }

    if ( !lightProgram.Build ( ) )
    {
        std :: cout << "ERROR: failed to build shader program\n"; exit ( -1 );
    }

    lightProgram.Bind ( );

        lightProgram.SetUniformVector ( "Light.Position", lightPosition );

        lightProgram.SetUniformVector ( "Light.Radius", lightRadius );

        lightProgram.SetUniformFloat ( "Light.Distance", lightDistance );

    lightProgram.Unbind ( );

    /* Load and compile shader files for VIEW PASS */

    ShaderProgram viewProgram;
    
    if ( !viewProgram.LoadVertexShader ( "Vertex.glsl" ) )
    {
        std :: cout << "ERROR: failed to load vertex shader\n"; exit ( -1 );
    }
    
	std::string prefix = "#define VIEW_PASS          \n\
             #define MAP_SIZE_X 256     \n\
             #define MAP_SIZE_Y	256		\n\
			 ";

#ifdef PHOTON_MAPPING
	prefix += "#define PHOTON_MAPPING		\n\
			 ";
#endif
#ifdef NAIVE_VERSION
	prefix += "#define NAIVE_VERSION		\n\
			 ";
#endif
#ifdef HALF_NAIVE_VERSION
		prefix += "#define HALF_NAIVE_VERSION		\n\
			 ";
#endif
#ifdef VOXEL_VERSION
	prefix += "#define VOXEL_VERSION		\n\
			 ";
#endif

    if ( !viewProgram.LoadFragmentShader ( "Fragment.glsl", prefix.c_str() ) )
    {
        std :: cout << "ERROR: failed to load fragment shader\n"; exit ( -1 );
    }

    if ( !viewProgram.Build ( ) )
    {
        std :: cout << "ERROR: failed to build shader program\n"; exit ( -1 );
    }

    viewProgram.Bind ( );

        viewProgram.SetUniformVector ( "Light.Position", lightPosition );

        viewProgram.SetTexture ( "PhotonMap", &photonMap );

		viewProgram.SetTexture ( "VoxelData", &voxelData );

        viewProgram.SetTexture ( "FloorColor", &floorColor );

        viewProgram.SetTexture ( "FloorNormal", &floorNormal );

        viewProgram.SetTexture ( "WallColor", &wallColor );

        viewProgram.SetTexture ( "WallNormal", &wallNormal );

        viewProgram.SetTexture ( "CeilColor", &ceilColor );

        viewProgram.SetTexture ( "CeilNormal", &ceilNormal );

    viewProgram.Unbind ( );

    //-------------------------------------------------------------------------

    /* Create frame buffer for rendering to the photon map */

    FrameBuffer lightBuffer;

    lightBuffer.ColorBuffers.push_back ( &photonMap );

    lightBuffer.Setup ( );

    //-------------------------------------------------------------------------
    
    GLboolean running = GL_TRUE;

    GLchar caption [100];

    GLint frames = 0;

    GLdouble fps = 0.0,
             delta = 0.0,
             time = 0.0,
             start = glfwGetTime ( );

    //-------------------------------------------------------------------------

    while ( running )
    {
        /* Calculate frames per second ( FPS ) */

        time = glfwGetTime ( );

        delta = time - start;

        if ( delta > 0.1 /* interval of FPS averaging */ )
        {
            fps = frames / delta;

            sprintf ( caption, "Caustics Demo - %.1f FPS", fps );

            glfwSetWindowTitle ( caption );

            start = time;

            frames = 0;
        }

        frames++;

        //---------------------------------------------------------------------

        /* Set new window size */

        glfwGetWindowSize ( &width, &height );      
        
        //---------------------------------------------------------------------

        /* Set new camera position and orientation */

        mouse.Apply ( &camera, fps );

        keyboard.Apply ( &camera, fps );

        //---------------------------------------------------------------------

        /* Moving metaballs */

        positions [0] (0) = sinf ( time ); 
        positions [0] (1) = -3.0F + 0.5F * cosf ( time );
        positions [0] (2) = cosf ( time ) * sinf ( time );

        positions [1] (0) = sinf ( time ); 
        positions [1] (1) = -3.0F + 1.0F * sinf ( time );
        positions [1] (2) = cosf ( time );

        positions [2] (0) = 1.3F * cosf ( time ); 
        positions [2] (1) = -3.0F + 0.2F * cosf ( time );
        positions [2] (2) = 1.5F * sin ( time );

        positions [3] (0) = 1.8F * sinf ( time ) * cosf ( time ); 
        positions [3] (1) = -3.0F + 1.2F * sinf ( time );
        positions [3] (2) = 1.4F * cosf ( time );

        //---------------------------------------------------------------------

        /* Draw dummy quad with custom fragment shader */

#ifdef PHOTON_MAPPING
        lightBuffer.Bind ( );

        lightProgram.Bind ( );

        lightProgram.SetUniformVector ( "Metaballs[0]", positions [0] );
        lightProgram.SetUniformVector ( "Metaballs[1]", positions [1] );
        lightProgram.SetUniformVector ( "Metaballs[2]", positions [2] );
        lightProgram.SetUniformVector ( "Metaballs[3]", positions [3] );

        glViewport ( 0, 0, N, M );

        glClear ( GL_COLOR_BUFFER_BIT );

        glBegin ( GL_QUADS );

        glVertex2f ( -1.0F, -1.0F );
        glVertex2f ( -1.0F,  1.0F );
        glVertex2f (  1.0F,  1.0F );
        glVertex2f (  1.0F, -1.0F );

        glEnd ( );

        lightProgram.Unbind ( );

        lightBuffer.Unbind ( );

        glFinish ( );

        /* Compute ray traced image using OpenCL kernel */
#ifndef NAIVE_VERSION

        GLdouble ss = glfwGetTime ( );

        cltAcquireGraphicsObject ( queue, photonImage );
		cltAcquireGraphicsObject ( queue, voxelImage );

        clFinish ( queue );

        StartKernels ( photonMap );

		cltReleaseGraphicsObject ( queue, voxelImage );
        cltReleaseGraphicsObject ( queue, photonImage );

        clFinish ( queue );

        GLdouble st = glfwGetTime ( ) - ss;

#endif

#endif

 //       std :: cout << st * 1000 << std :: endl;

        /* Draw dummy quad with custom fragment shader */
        
        camera.SetViewport ( width, height );

        viewProgram.Bind ( );

        viewProgram.SetUniformVector ( "Metaballs[0]", positions [0] );
        viewProgram.SetUniformVector ( "Metaballs[1]", positions [1] );
        viewProgram.SetUniformVector ( "Metaballs[2]", positions [2] );
        viewProgram.SetUniformVector ( "Metaballs[3]", positions [3] );

        camera.SetShaderData ( &viewProgram );
        
        glBegin ( GL_QUADS );

            glVertex2f ( -1.0F, -1.0F );
            glVertex2f ( -1.0F,  1.0F );
            glVertex2f (  1.0F,  1.0F );
            glVertex2f (  1.0F, -1.0F );

        glEnd ( );

        viewProgram.Unbind ( );

        glfwSwapBuffers ( );

        //---------------------------------------------------------------------
        
        running = !glfwGetKey ( GLFW_KEY_ESC ) &&
            glfwGetWindowParam ( GLFW_OPENED );
    }

    ReleaseOpenCL ( );

    glfwTerminate ( ); exit ( 0 );
}